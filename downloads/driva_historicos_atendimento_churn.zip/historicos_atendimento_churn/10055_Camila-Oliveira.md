# Histórico de atendimento — Cliente #10055 · Camila Oliveira

- **Plano:** Essencial (Chevrolet Onix) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** ABC · **Uso:** 2166 km/mês · **Health score:** 47
- **Cliente desde:** 2026-01-28 · **Cancelou em:** 2026-06-11
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** “cobrança surpresa de avaria, achei um absurdo”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810032 · 2026-04-10 · whatsapp · Cobrança · CSAT 2/5

`12:07 UTC` **Cliente:** acabei de ver uma cobrança de R$ 1620 na minha fatura que eu não reconheço
`12:26 UTC` **Driva:** Oi, Camila! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`12:40 UTC` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`12:45 UTC` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`12:51 UTC` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810033 · 2026-05-02 · whatsapp · Cobrança · CSAT 2/5

`20:20 UTC` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`20:23 UTC` **Driva:** Camila, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`20:34 UTC` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810034 · 2026-06-11 · whatsapp · Cancelamento · CSAT 1/5

`18:27 UTC` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`18:47 UTC` **Driva:** Camila, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`18:53 UTC` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`19:09 UTC` **Driva:** Entendo. Qual motivo você quer que eu registre?
`19:26 UTC` **Cliente:** marca comprei carro próprio aí, é mais fácil

---
