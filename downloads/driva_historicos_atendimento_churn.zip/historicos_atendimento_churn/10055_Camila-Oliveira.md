# Histórico de atendimento — Cliente #10055 · Camila Oliveira

- **Plano:** Essencial (Chevrolet Onix) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** ABC · **Uso:** 2166 km/mês · **Health score:** 47
- **Cliente desde** 2026-01-28 · **Cancelou em** 2026-06-11
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** "cobrança surpresa de avaria, achei um absurdo"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810032 · 2026-06-05 · whatsapp · Cobrança · CSAT 2/5

`19:00` **Cliente:** acabei de ver uma cobrança de R$ 1250 na minha fatura que eu não reconheço
`19:10` **Driva:** Oi, Camila! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`19:30` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`19:47` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`19:55` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810033 · 2026-06-10 · whatsapp · Cobrança · CSAT 2/5

`12:22` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`12:25` **Driva:** Camila, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`12:37` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810034 · 2026-06-11 · whatsapp · Cancelamento · CSAT 1/5

`19:31` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`19:40` **Driva:** Camila, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`19:43` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`19:50` **Driva:** Entendo. Qual motivo você quer que eu registre?
`20:07` **Cliente:** pode botar que comprei um carro próprio, deixa quieto

---
