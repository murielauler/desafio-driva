# Histórico de atendimento — Cliente #10033 · Jefferson Martins

- **Plano:** Essencial (Renault Kwid) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Sul · **Uso:** 983 km/mês · **Health score:** 71
- **Cliente desde** 2025-09-25 · **Cancelou em** 2026-06-10
- **Motivo registrado pela retenção:** parou_de_rodar
- **Comentário no cancelamento:** "só usava fim de semana, ficou caro"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810027 · 2026-05-01 · whatsapp · Planos · CSAT 3/5

`12:44` **Cliente:** boa tarde, eu uso o carro bem pouco, só pra ir e voltar do trabalho. tem um plano mais barato pra quem roda pouco?
`13:04` **Driva:** Boa tarde, Jefferson! Hoje trabalhamos com os planos Essencial e Conforto, sem uma faixa de baixa quilometragem no momento.
`13:06` **Cliente:** poxa, pagar o mesmo que quem roda o dia todo não compensa pra mim
`13:17` **Driva:** Entendo seu ponto. Posso te mostrar se o Essencial reduz um pouco o custo?
`13:20` **Cliente:** é que mesmo o essencial tá caro pro tanto que eu ando

---

### Ticket #810028 · 2026-06-10 · whatsapp · Cancelamento · CSAT 2/5

`14:02` **Cliente:** vou cancelar, pro meu uso não vale a pena o valor semanal
`14:14` **Driva:** Jefferson, respeito. Se em algum momento lançarmos um plano de baixa km, posso te avisar?
`14:27` **Cliente:** pode, mas por ora encerra aí
`14:33` **Driva:** Feito. Registro como qual motivo?
`14:51` **Cliente:** põe que parei de rodar

---
