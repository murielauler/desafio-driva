# Histórico de atendimento — Cliente #10033 · Jefferson Martins

- **Plano:** Essencial (Renault Kwid) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Sul · **Uso:** 983 km/mês · **Health score:** 71
- **Cliente desde:** 2025-09-25 · **Cancelou em:** 2026-06-10
- **Motivo registrado pela retenção:** parou_de_rodar
- **Comentário no cancelamento:** “só usava fim de semana, ficou caro”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810027 · 2026-03-18 · whatsapp · Planos · CSAT 3/5

`15:02 UTC` **Cliente:** boa tarde, eu uso o carro bem pouco, só pra ir e voltar do trabalho. tem um plano mais barato pra quem roda pouco?
`15:13 UTC` **Driva:** Boa tarde, Jefferson! Hoje trabalhamos com os planos Essencial e Conforto, sem uma faixa de baixa quilometragem no momento.
`15:19 UTC` **Cliente:** poxa, pagar o mesmo que quem roda o dia todo não compensa pra mim
`15:22 UTC` **Driva:** Entendo seu ponto. Posso te mostrar se o Essencial reduz um pouco o custo?
`15:34 UTC` **Cliente:** é que mesmo o essencial tá caro pro tanto que eu ando

---

### Ticket #810028 · 2026-06-10 · whatsapp · Cancelamento · CSAT 2/5

`15:49 UTC` **Cliente:** vou cancelar, pro meu uso não vale a pena o valor semanal
`15:59 UTC` **Driva:** Jefferson, respeito. Se em algum momento lançarmos um plano de baixa km, posso te avisar?
`16:19 UTC` **Cliente:** pode, mas por ora encerra aí
`16:36 UTC` **Driva:** Feito. Registro como qual motivo?
`16:44 UTC` **Cliente:** marca que parei de rodar mesmo

---
