# Histórico de atendimento — Cliente #10014 · Anderson Cardoso

- **Plano:** Essencial (VW Gol) · **Perfil:** motorista_app · **App:** 99
- **Região:** Zona Sul · **Uso:** 2369 km/mês · **Health score:** 90
- **Cliente desde:** 2024-08-27 · **Cancelou em:** 2026-06-26
- **Motivo registrado pela retenção:** mudou_de_cidade
- **Comentário no cancelamento:** “consegui comprar meu próprio carro, valeu pela parceria”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810007 · 2025-01-01 · whatsapp · Dúvida app · CSAT 4/5

`11:57 UTC` **Cliente:** oi, tudo certo? só uma dúvida de como pausar a cobrança se eu viajar
`12:09 UTC` **Driva:** Oi, Anderson! Consigo te explicar sim, é bem simples.
`12:11 UTC` **Cliente:** show, obrigado pelo atendimento sempre rápido

---

### Ticket #810008 · 2026-06-26 · whatsapp · Cancelamento · CSAT 5/5

`17:18 UTC` **Cliente:** boa, preciso cancelar, vou me mudar de cidade mês que vem
`17:35 UTC` **Driva:** Que notícia boa, Anderson! Fico feliz pela conquista. Foi um prazer ter você com a gente.
`17:52 UTC` **Cliente:** vocês me ajudaram bastante nesse período, valeu de verdade
`17:57 UTC` **Driva:** Gratidão! A porta fica aberta se precisar voltar. 🧡

---
