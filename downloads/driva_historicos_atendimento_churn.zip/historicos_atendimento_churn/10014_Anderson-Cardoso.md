# Histórico de atendimento — Cliente #10014 · Anderson Cardoso

- **Plano:** Essencial (VW Gol) · **Perfil:** motorista_app · **App:** 99
- **Região:** Zona Sul · **Uso:** 2369 km/mês · **Health score:** 90
- **Cliente desde** 2024-08-27 · **Cancelou em** 2026-06-26
- **Motivo registrado pela retenção:** mudou_de_cidade
- **Comentário no cancelamento:** "consegui comprar meu próprio carro, valeu pela parceria"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810007 · 2026-05-30 · whatsapp · Dúvida app · CSAT 4/5

`17:54` **Cliente:** oi, tudo certo? só uma dúvida de como pausar a cobrança se eu viajar
`18:01` **Driva:** Oi, Anderson! Consigo te explicar sim, é bem simples.
`18:05` **Cliente:** show, obrigado pelo atendimento sempre rápido

---

### Ticket #810008 · 2026-06-26 · whatsapp · Cancelamento · CSAT 5/5

`12:14` **Cliente:** boa, preciso cancelar, vou me mudar de cidade mês que vem
`12:28` **Driva:** Que notícia boa, Anderson! Fico feliz pela conquista. Foi um prazer ter você com a gente.
`12:33` **Cliente:** vocês me ajudaram bastante nesse período, valeu de verdade
`12:43` **Driva:** Gratidão! A porta fica aberta se precisar voltar. 🧡

---
