# Histórico de atendimento — Cliente #10031 · Camila Souza

- **Plano:** Essencial (Renault Kwid) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Norte · **Uso:** 2116 km/mês · **Health score:** 47
- **Cliente desde:** 2024-07-11 · **Cancelou em:** 2026-06-14
- **Motivo registrado pela retenção:** outro
- **Comentário no cancelamento:** “me cobraram 1.400 do nada por uma batida que nem foi culpa minha”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810024 · 2025-05-25 · whatsapp · Cobrança · CSAT 2/5

`08:33 UTC` **Cliente:** acabei de ver uma cobrança de R$ 980 na minha fatura que eu não reconheço
`08:52 UTC` **Driva:** Oi, Camila! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`09:00 UTC` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`09:14 UTC` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`09:29 UTC` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810025 · 2025-11-06 · whatsapp · Cobrança · CSAT 2/5

`13:29 UTC` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`13:47 UTC` **Driva:** Camila, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`14:07 UTC` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810026 · 2026-06-14 · whatsapp · Cancelamento · CSAT 1/5

`09:13 UTC` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`09:15 UTC` **Driva:** Camila, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`09:34 UTC` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`09:50 UTC` **Driva:** Entendo. Qual motivo você quer que eu registre?
`10:02 UTC` **Cliente:** sei lá, marca como 'outro' aí

---
