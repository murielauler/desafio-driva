# Histórico de atendimento — Cliente #10031 · Camila Souza

- **Plano:** Essencial (Renault Kwid) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Norte · **Uso:** 2116 km/mês · **Health score:** 47
- **Cliente desde** 2024-07-11 · **Cancelou em** 2026-06-14
- **Motivo registrado pela retenção:** outro
- **Comentário no cancelamento:** "me cobraram 1.400 do nada por uma batida que nem foi culpa minha"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810024 · 2026-05-01 · whatsapp · Cobrança · CSAT 2/5

`13:15` **Cliente:** acabei de ver uma cobrança de R$ 980 na minha fatura que eu não reconheço
`13:29` **Driva:** Oi, Camila! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`13:48` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`14:03` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`14:12` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810025 · 2026-05-17 · whatsapp · Cobrança · CSAT 2/5

`11:40` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`11:51` **Driva:** Camila, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`11:55` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810026 · 2026-06-14 · whatsapp · Cancelamento · CSAT 1/5

`08:53` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`09:13` **Driva:** Camila, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`09:21` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`09:26` **Driva:** Entendo. Qual motivo você quer que eu registre?
`09:46` **Cliente:** sei lá, marca como 'outro' aí

---
