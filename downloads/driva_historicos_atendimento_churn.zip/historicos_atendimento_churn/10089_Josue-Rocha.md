# Histórico de atendimento — Cliente #10089 · Josué Rocha

- **Plano:** Essencial (Fiat Mobi) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Sul · **Uso:** 998 km/mês · **Health score:** 32
- **Cliente desde:** 2026-05-13 · **Cancelou em:** 2026-05-22
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** “demorou pra liberar o carro, arrumei outra coisa”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810049 · 2026-05-13 · whatsapp · Onboarding · CSAT 3/5

`18:31 UTC` **Cliente:** oi, assinei e paguei a primeira semana, e agora? quando pego o carro?
`18:40 UTC` **Driva:** Oi, Josué! Boas-vindas 🎉 Falta só a vistoria pra liberar. Um consultor vai te chamar pra agendar.
`18:43 UTC` **Cliente:** beleza, fico no aguardo então

---

### Ticket #810050 · 2026-05-19 · whatsapp · Onboarding · CSAT 2/5

`09:46 UTC` **Cliente:** gente já faz 7 dias e ninguém agendou minha vistoria. cadê o carro?
`09:54 UTC` **Driva:** Josué, sinto muito pela demora. Vou priorizar seu agendamento e te retorno hoje.
`10:00 UTC` **Cliente:** é a segunda vez que me falam isso. cada dia parado é dinheiro que não entra

---

### Ticket #810051 · 2026-05-22 · whatsapp · Cancelamento · CSAT 1/5

`17:28 UTC` **Cliente:** desisti. quero cancelar e pedir o estorno da semana que paguei sem nem ter recebido o carro
`17:38 UTC` **Driva:** Josué, você tem razão e isso não deveria ter acontecido. Vou processar o estorno e registrar o cancelamento.
`17:44 UTC` **Cliente:** arrumei outra solução já, não dá pra esperar vocês
`17:59 UTC` **Driva:** Entendo. Registro algum motivo específico?
`18:03 UTC` **Cliente:** pode botar que comprei um carro próprio, deixa quieto

---
