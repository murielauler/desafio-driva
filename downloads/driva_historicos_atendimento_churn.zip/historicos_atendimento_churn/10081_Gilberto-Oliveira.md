# Histórico de atendimento — Cliente #10081 · Gilberto Oliveira

- **Plano:** Essencial (Renault Kwid) · **Perfil:** motorista_app · **App:** 99
- **Região:** Zona Norte · **Uso:** 2554 km/mês · **Health score:** 43
- **Cliente desde** 2025-02-27 · **Cancelou em** 2026-06-13
- **Motivo registrado pela retenção:** outro
- **Comentário no cancelamento:** "cobrança surpresa de avaria, achei um absurdo"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810043 · 2025-11-04 · whatsapp · Cobrança · CSAT 2/5

`12:26` **Cliente:** acabei de ver uma cobrança de R$ 1480 na minha fatura que eu não reconheço
`12:40` **Driva:** Oi, Gilberto! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`12:44` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`13:00` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`13:14` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810044 · 2026-01-15 · whatsapp · Cobrança · CSAT 2/5

`18:13` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`18:26` **Driva:** Gilberto, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`18:28` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810045 · 2026-06-13 · whatsapp · Cancelamento · CSAT 1/5

`09:13` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`09:18` **Driva:** Gilberto, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`09:35` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`09:53` **Driva:** Entendo. Qual motivo você quer que eu registre?
`10:02` **Cliente:** sei lá, marca como 'outro' aí

---
