# Histórico de atendimento — Cliente #10081 · Gilberto Oliveira

- **Plano:** Essencial (Renault Kwid) · **Perfil:** motorista_app · **App:** 99
- **Região:** Zona Norte · **Uso:** 2554 km/mês · **Health score:** 43
- **Cliente desde:** 2025-02-27 · **Cancelou em:** 2026-06-13
- **Motivo registrado pela retenção:** outro
- **Comentário no cancelamento:** “cobrança surpresa de avaria, achei um absurdo”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810043 · 2025-09-16 · whatsapp · Cobrança · CSAT 2/5

`16:58 UTC` **Cliente:** acabei de ver uma cobrança de R$ 980 na minha fatura que eu não reconheço
`17:16 UTC` **Driva:** Oi, Gilberto! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`17:33 UTC` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`17:37 UTC` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`17:55 UTC` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810044 · 2025-11-20 · whatsapp · Cobrança · CSAT 2/5

`10:47 UTC` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`10:54 UTC` **Driva:** Gilberto, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`11:01 UTC` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810045 · 2026-06-13 · whatsapp · Cancelamento · CSAT 1/5

`16:54 UTC` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`17:06 UTC` **Driva:** Gilberto, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`17:11 UTC` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`17:14 UTC` **Driva:** Entendo. Qual motivo você quer que eu registre?
`17:20 UTC` **Cliente:** sei lá, marca como 'outro' aí

---
