# Histórico de atendimento — Cliente #10060 · Diego Ferreira

- **Plano:** Essencial (Renault Kwid) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Sul · **Uso:** 2538 km/mês · **Health score:** 99
- **Cliente desde** 2025-11-20 · **Cancelou em** 2026-06-22
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** "achei uma opção melhor, valeu"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810038 · 2026-02-05 · whatsapp · Manutenção · CSAT 2/5

`15:05` **Cliente:** de novo problema no carro... tá difícil viu
`15:25` **Driva:** Diego, sinto muito. Vou abrir o chamado e resolver o quanto antes.
`15:31` **Cliente:** tô começando a achar que não vale a pena

---

### Ticket #810039 · 2026-06-22 · whatsapp · Cancelamento · CSAT 2/5

`19:19` **Cliente:** quero encerrar. achei uma opção melhor que me atende mais rápido
`19:30` **Driva:** Diego, poxa. Posso perguntar o que pesou na decisão?
`19:36` **Cliente:** sinceramente o atendimento e o carro reserva na hora, que aqui demora
`19:44` **Driva:** Justo. Que motivo você quer que eu registre no sistema?
`19:52` **Cliente:** tanto faz, pode cancelar sem marcar

---
