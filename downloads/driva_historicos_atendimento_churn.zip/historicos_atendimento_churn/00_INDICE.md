# Índice — Históricos de atendimento de clientes que cancelaram

Material fictício de treinamento. Os 20 arquivos abaixo são a versão legível das mesmas 53 conversas presentes no export JSON.

| Cliente | Perfil | Cancelamento | Tickets | Arquivo |
|---|---|---:|---:|---|
| #10001 · Rafael Silva | motorista_app | 2026-06-17 | 3 | [10001_Rafael-Silva.md](10001_Rafael-Silva.md) |
| #10003 · Diego Martins | motorista_app | 2026-06-06 | 3 | [10003_Diego-Martins.md](10003_Diego-Martins.md) |
| #10014 · Anderson Cardoso | motorista_app | 2026-06-26 | 2 | [10014_Anderson-Cardoso.md](10014_Anderson-Cardoso.md) |
| #10016 · Tatiane Almeida | motorista_app | 2026-06-13 | 3 | [10016_Tatiane-Almeida.md](10016_Tatiane-Almeida.md) |
| #10017 · Juliana Cardoso | motorista_app | 2026-06-11 | 3 | [10017_Juliana-Cardoso.md](10017_Juliana-Cardoso.md) |
| #10018 · Marcelo Martins | pessoal | 2026-06-09 | 2 | [10018_Marcelo-Martins.md](10018_Marcelo-Martins.md) |
| #10020 · Tatiane Souza | pessoal | 2026-06-28 | 2 | [10020_Tatiane-Souza.md](10020_Tatiane-Souza.md) |
| #10021 · Bruno Pereira | pessoal | 2026-06-09 | 3 | [10021_Bruno-Pereira.md](10021_Bruno-Pereira.md) |
| #10027 · Tatiane Gomes | motorista_app | 2026-06-19 | 2 | [10027_Tatiane-Gomes.md](10027_Tatiane-Gomes.md) |
| #10031 · Camila Souza | motorista_app | 2026-06-14 | 3 | [10031_Camila-Souza.md](10031_Camila-Souza.md) |
| #10033 · Jefferson Martins | motorista_app | 2026-06-10 | 2 | [10033_Jefferson-Martins.md](10033_Jefferson-Martins.md) |
| #10038 · Renata Gomes | motorista_app | 2026-06-12 | 3 | [10038_Renata-Gomes.md](10038_Renata-Gomes.md) |
| #10055 · Camila Oliveira | motorista_app | 2026-06-11 | 3 | [10055_Camila-Oliveira.md](10055_Camila-Oliveira.md) |
| #10059 · Josué Souza | motorista_app | 2026-06-06 | 3 | [10059_Josue-Souza.md](10059_Josue-Souza.md) |
| #10060 · Diego Ferreira | motorista_app | 2026-06-22 | 2 | [10060_Diego-Ferreira.md](10060_Diego-Ferreira.md) |
| #10071 · Wagner Nascimento | motorista_app | 2026-06-30 | 3 | [10071_Wagner-Nascimento.md](10071_Wagner-Nascimento.md) |
| #10081 · Gilberto Oliveira | motorista_app | 2026-06-13 | 3 | [10081_Gilberto-Oliveira.md](10081_Gilberto-Oliveira.md) |
| #10087 · Bruno Moreira | motorista_app | 2026-06-30 | 3 | [10087_Bruno-Moreira.md](10087_Bruno-Moreira.md) |
| #10089 · Josué Rocha | motorista_app | 2026-05-22 | 3 | [10089_Josue-Rocha.md](10089_Josue-Rocha.md) |
| #10093 · Wesley Santos | motorista_app | 2026-06-23 | 2 | [10093_Wesley-Santos.md](10093_Wesley-Santos.md) |

Os horários dos arquivos estão em UTC, conforme o export JSON.
