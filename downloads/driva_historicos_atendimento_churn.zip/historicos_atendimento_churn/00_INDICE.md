# Índice — 20 clientes churnados

| # | Cliente | Plano | Motivo REGISTRADO | Nº tickets |
|---|---------|-------|-------------------|-----------|
| 1 | #10001 Rafael Silva | Conforto | (em branco) | 3 |
| 2 | #10003 Diego Martins | Conforto | comprou_carro_proprio | 3 |
| 3 | #10014 Anderson Cardoso | Essencial | mudou_de_cidade | 2 |
| 4 | #10016 Tatiane Almeida | Essencial | (em branco) | 3 |
| 5 | #10017 Juliana Cardoso | Conforto | problemas_manutencao | 3 |
| 6 | #10018 Marcelo Martins | Essencial | mudou_de_cidade | 2 |
| 7 | #10020 Tatiane Souza | Essencial | comprou_carro_proprio | 2 |
| 8 | #10021 Bruno Pereira | Essencial | comprou_carro_proprio | 3 |
| 9 | #10027 Tatiane Gomes | Conforto | comprou_carro_proprio | 2 |
| 10 | #10031 Camila Souza | Essencial | outro | 3 |
| 11 | #10033 Jefferson Martins | Essencial | parou_de_rodar | 2 |
| 12 | #10038 Renata Gomes | Conforto | (em branco) | 3 |
| 13 | #10055 Camila Oliveira | Essencial | comprou_carro_proprio | 3 |
| 14 | #10059 Josué Souza | Essencial | achei_caro | 3 |
| 15 | #10060 Diego Ferreira | Essencial | (em branco) | 2 |
| 16 | #10071 Wagner Nascimento | Essencial | outro | 3 |
| 17 | #10081 Gilberto Oliveira | Essencial | outro | 3 |
| 18 | #10087 Bruno Moreira | Conforto | problemas_manutencao | 3 |
| 19 | #10089 Josué Rocha | Essencial | comprou_carro_proprio | 3 |
| 20 | #10093 Wesley Santos | Essencial | (em branco) | 2 |