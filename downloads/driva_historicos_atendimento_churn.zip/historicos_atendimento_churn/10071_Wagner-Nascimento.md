# Histórico de atendimento — Cliente #10071 · Wagner Nascimento

- **Plano:** Essencial (Fiat Mobi) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Oeste · **Uso:** 2788 km/mês · **Health score:** 65
- **Cliente desde:** 2024-09-16 · **Cancelou em:** 2026-06-30
- **Motivo registrado pela retenção:** outro
- **Comentário no cancelamento:** “carro vivia na oficina, perdi vários dias de corrida”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810040 · 2026-01-29 · whatsapp · Manutenção · CSAT 2/5

`18:52 UTC` **Cliente:** a luz da injeção acendeu e o carro tá falhando feio
`19:01 UTC` **Driva:** Boa tarde, Wagner! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`19:03 UTC` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`19:23 UTC` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`19:43 UTC` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810041 · 2026-06-26 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`15:31 UTC` **Cliente:** o carro morreu aqui na Radial Leste, não liga de jeito nenhum. preciso de guincho AGORA
`15:36 UTC` **Driva:** Wagner, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`15:42 UTC` **Cliente:** quanto tempo demora?
`16:02 UTC` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`18:22 UTC` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`19:57 UTC` **Cliente:** 3h30 esperando. perdi a tarde inteira de trabalho. isso não dá
`20:04 UTC` **Driva:** Sinto muito de verdade pela demora, Wagner. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`20:18 UTC` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810042 · 2026-06-30 · whatsapp · Cancelamento · CSAT 1/5

`18:25 UTC` **Cliente:** oi, quero cancelar a assinatura
`18:36 UTC` **Driva:** Wagner, que pena ouvir isso. Posso entender o que motivou?
`18:56 UTC` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`19:02 UTC` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`19:07 UTC` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`19:19 UTC` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`19:23 UTC` **Cliente:** bota 'outro' mesmo, tanto faz

---
