# Histórico de atendimento — Cliente #10071 · Wagner Nascimento

- **Plano:** Essencial (Fiat Mobi) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Oeste · **Uso:** 2788 km/mês · **Health score:** 65
- **Cliente desde** 2024-09-16 · **Cancelou em** 2026-06-30
- **Motivo registrado pela retenção:** outro
- **Comentário no cancelamento:** "carro vivia na oficina, perdi vários dias de corrida"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810040 · 2024-09-25 · whatsapp · Manutenção · CSAT 2/5

`19:53` **Cliente:** gente o carro não pega direito de manhã, já travou 2x essa semana
`19:58` **Driva:** Bom dia, Wagner! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`20:04` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`20:18` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`20:33` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810041 · 2025-03-18 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`08:12` **Cliente:** o carro morreu aqui na Marginal Pinheiros, não liga de jeito nenhum. preciso de guincho AGORA
`08:25` **Driva:** Wagner, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`08:31` **Cliente:** quanto tempo demora?
`08:48` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`11:08` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`12:43` **Cliente:** 3h30 esperando. perdi a manhã inteira de trabalho. isso não dá
`12:50` **Driva:** Sinto muito de verdade pela demora, Wagner. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`12:53` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810042 · 2026-06-30 · whatsapp · Cancelamento · CSAT 1/5

`16:09` **Cliente:** oi, quero cancelar a assinatura
`16:29` **Driva:** Wagner, que pena ouvir isso. Posso entender o que motivou?
`16:44` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`16:50` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`17:04` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`17:13` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`17:16` **Cliente:** sei lá, marca como 'outro' aí

---
