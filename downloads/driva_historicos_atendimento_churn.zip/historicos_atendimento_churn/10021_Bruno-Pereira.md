# Histórico de atendimento — Cliente #10021 · Bruno Pereira

- **Plano:** Essencial (Fiat Mobi) · **Perfil:** pessoal · **App:** Uso pessoal
- **Região:** Zona Leste · **Uso:** 547 km/mês · **Health score:** 55
- **Cliente desde:** 2025-10-06 · **Cancelou em:** 2026-06-09
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** “cobrança surpresa de avaria, achei um absurdo”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810019 · 2026-03-25 · whatsapp · Cobrança · CSAT 2/5

`15:22 UTC` **Cliente:** acabei de ver uma cobrança de R$ 1250 na minha fatura que eu não reconheço
`15:28 UTC` **Driva:** Oi, Bruno! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`15:47 UTC` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`16:04 UTC` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`16:08 UTC` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810020 · 2026-05-08 · whatsapp · Cobrança · CSAT 2/5

`11:19 UTC` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`11:23 UTC` **Driva:** Bruno, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`11:35 UTC` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810021 · 2026-06-09 · whatsapp · Cancelamento · CSAT 1/5

`19:38 UTC` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`19:57 UTC` **Driva:** Bruno, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`20:12 UTC` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`20:21 UTC` **Driva:** Entendo. Qual motivo você quer que eu registre?
`20:30 UTC` **Cliente:** marca comprei carro próprio aí, é mais fácil

---
