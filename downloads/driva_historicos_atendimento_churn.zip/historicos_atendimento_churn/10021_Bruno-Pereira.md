# Histórico de atendimento — Cliente #10021 · Bruno Pereira

- **Plano:** Essencial (Fiat Mobi) · **Perfil:** pessoal · **App:** Uso pessoal
- **Região:** Zona Leste · **Uso:** 547 km/mês · **Health score:** 55
- **Cliente desde** 2025-10-06 · **Cancelou em** 2026-06-09
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** "cobrança surpresa de avaria, achei um absurdo"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810019 · 2026-05-17 · whatsapp · Cobrança · CSAT 2/5

`15:15` **Cliente:** acabei de ver uma cobrança de R$ 1620 na minha fatura que eu não reconheço
`15:31` **Driva:** Oi, Bruno! Deixa eu verificar aqui... consta uma cobrança de avaria registrada na última vistoria.
`15:36` **Cliente:** avaria?? que avaria? ninguém me falou nada, apareceu do nada na fatura
`15:53` **Driva:** Vou levantar as fotos da vistoria de entrega e retorno pra gente comparar, tá?
`16:12` **Cliente:** faz isso porque eu não causei dano nenhum nesse carro

---

### Ticket #810020 · 2026-05-26 · whatsapp · Cobrança · CSAT 2/5

`11:27` **Cliente:** e aí, conseguiu ver as fotos? já faz 4 dias
`11:34` **Driva:** Bruno, ainda estou aguardando a base enviar as imagens. Assim que chegar eu te falo.
`11:38` **Cliente:** enquanto isso a cobrança tá lá me sufocando. isso é muito errado

---

### Ticket #810021 · 2026-06-09 · whatsapp · Cancelamento · CSAT 1/5

`14:37` **Cliente:** quero cancelar. não confio mais nessa cobrança de vocês
`14:44` **Driva:** Bruno, sinto muito. Se o problema é a cobrança contestada, posso escalar pra resolver antes de você decidir.
`14:56` **Cliente:** já decidi. cansei de susto na fatura. encerra por favor
`15:10` **Driva:** Entendo. Qual motivo você quer que eu registre?
`15:20` **Cliente:** pode botar que comprei um carro próprio, deixa quieto

---
