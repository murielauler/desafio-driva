# Histórico de atendimento — Cliente #10016 · Tatiane Almeida

- **Plano:** Essencial (VW Gol) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Norte · **Uso:** 3033 km/mês · **Health score:** 43
- **Cliente desde** 2024-08-05 · **Cancelou em** 2026-06-13
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** "carro vivia na oficina, perdi vários dias de corrida"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810009 · 2024-09-04 · whatsapp · Manutenção · CSAT 2/5

`11:27` **Cliente:** a luz da injeção acendeu e o carro tá falhando feio
`11:44` **Driva:** Bom dia, Tatiane! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`11:49` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`11:51` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`11:54` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810010 · 2025-06-05 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`20:01` **Cliente:** o carro morreu aqui na Radial Leste, não liga de jeito nenhum. preciso de guincho AGORA
`20:21` **Driva:** Tatiane, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`20:27` **Cliente:** quanto tempo demora?
`20:30` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`22:50` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`00:25` **Cliente:** 3h30 esperando. perdi a manhã inteira de trabalho. isso não dá
`00:30` **Driva:** Sinto muito de verdade pela demora, Tatiane. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`00:38` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810011 · 2026-06-13 · whatsapp · Cancelamento · CSAT 1/5

`13:52` **Cliente:** oi, quero cancelar a assinatura
`14:02` **Driva:** Tatiane, que pena ouvir isso. Posso entender o que motivou?
`14:19` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`14:36` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`14:48` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`15:03` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`15:15` **Cliente:** ah deixa quieto, não precisa marcar nada, só encerra

---
