# Histórico de atendimento — Cliente #10016 · Tatiane Almeida

- **Plano:** Essencial (VW Gol) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Norte · **Uso:** 3033 km/mês · **Health score:** 43
- **Cliente desde:** 2024-08-05 · **Cancelou em:** 2026-06-13
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** “carro vivia na oficina, perdi vários dias de corrida”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810009 · 2026-03-24 · whatsapp · Manutenção · CSAT 2/5

`08:57 UTC` **Cliente:** opa bom dia, o VW Gol tá engasgando e perdendo força na subida
`09:15 UTC` **Driva:** Bom dia, Tatiane! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`09:17 UTC` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`09:31 UTC` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`09:49 UTC` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810010 · 2026-04-29 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`15:44 UTC` **Cliente:** o carro morreu aqui na Av. do Estado, não liga de jeito nenhum. preciso de guincho AGORA
`15:56 UTC` **Driva:** Tatiane, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`16:02 UTC` **Cliente:** quanto tempo demora?
`16:17 UTC` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`18:37 UTC` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`20:12 UTC` **Cliente:** 3h30 esperando. perdi a tarde inteira de trabalho. isso não dá
`20:24 UTC` **Driva:** Sinto muito de verdade pela demora, Tatiane. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`20:37 UTC` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810011 · 2026-06-13 · whatsapp · Cancelamento · CSAT 1/5

`12:41 UTC` **Cliente:** oi, quero cancelar a assinatura
`12:54 UTC` **Driva:** Tatiane, que pena ouvir isso. Posso entender o que motivou?
`13:08 UTC` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`13:22 UTC` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`13:25 UTC` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`13:38 UTC` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`13:50 UTC` **Cliente:** tanto faz, pode cancelar sem marcar

---
