# Histórico de atendimento — Cliente #10038 · Renata Gomes

- **Plano:** Conforto (VW Virtus) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Sul · **Uso:** 899 km/mês · **Health score:** 25
- **Cliente desde:** 2026-05-24 · **Cancelou em:** 2026-06-12
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** “demorou pra liberar o carro, arrumei outra coisa”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810029 · 2026-05-26 · whatsapp · Onboarding · CSAT 3/5

`09:54 UTC` **Cliente:** oi, assinei e paguei a primeira semana, e agora? quando pego o carro?
`10:03 UTC` **Driva:** Oi, Renata! Boas-vindas 🎉 Falta só a vistoria pra liberar. Um consultor vai te chamar pra agendar.
`10:06 UTC` **Cliente:** beleza, fico no aguardo então

---

### Ticket #810030 · 2026-06-11 · whatsapp · Onboarding · CSAT 2/5

`10:30 UTC` **Cliente:** gente já faz 17 dias e ninguém agendou minha vistoria. cadê o carro?
`10:44 UTC` **Driva:** Renata, sinto muito pela demora. Vou priorizar seu agendamento e te retorno hoje.
`10:55 UTC` **Cliente:** é a segunda vez que me falam isso. cada dia parado é dinheiro que não entra

---

### Ticket #810031 · 2026-06-12 · whatsapp · Cancelamento · CSAT 1/5

`07:51 UTC` **Cliente:** desisti. quero cancelar e pedir o estorno da semana que paguei sem nem ter recebido o carro
`08:05 UTC` **Driva:** Renata, você tem razão e isso não deveria ter acontecido. Vou processar o estorno e registrar o cancelamento.
`08:17 UTC` **Cliente:** arrumei outra solução já, não dá pra esperar vocês
`08:32 UTC` **Driva:** Entendo. Registro algum motivo específico?
`08:49 UTC` **Cliente:** ah deixa quieto, não precisa marcar nada, só encerra

---
