# Histórico de atendimento — Cliente #10038 · Renata Gomes

- **Plano:** Conforto (VW Virtus) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Sul · **Uso:** 899 km/mês · **Health score:** 25
- **Cliente desde** 2026-05-24 · **Cancelou em** 2026-06-12
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** "demorou pra liberar o carro, arrumei outra coisa"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810029 · 2026-05-25 · whatsapp · Onboarding · CSAT 3/5

`09:13` **Cliente:** oi, assinei e paguei a primeira semana, e agora? quando pego o carro?
`09:15` **Driva:** Oi, Renata! Boas-vindas 🎉 Falta só a vistoria pra liberar. Um consultor vai te chamar pra agendar.
`09:34` **Cliente:** beleza, fico no aguardo então

---

### Ticket #810030 · 2026-06-11 · whatsapp · Onboarding · CSAT 2/5

`15:13` **Cliente:** gente já faz 17 dias e ninguém agendou minha vistoria. cadê o carro?
`15:19` **Driva:** Renata, sinto muito pela demora. Vou priorizar seu agendamento e te retorno hoje.
`15:30` **Cliente:** é a segunda vez que me falam isso. cada dia parado é dinheiro que não entra

---

### Ticket #810031 · 2026-06-12 · whatsapp · Cancelamento · CSAT 1/5

`15:57` **Cliente:** desisti. quero cancelar e pedir o estorno da semana que paguei sem nem ter recebido o carro
`16:03` **Driva:** Renata, você tem razão e isso não deveria ter acontecido. Vou processar o estorno e registrar o cancelamento.
`16:14` **Cliente:** arrumei outra solução já, não dá pra esperar vocês
`16:20` **Driva:** Entendo. Registro algum motivo específico?
`16:23` **Cliente:** ah deixa quieto, não precisa marcar nada, só encerra

---
