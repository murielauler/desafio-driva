# Histórico de atendimento — Cliente #10001 · Rafael Silva

- **Plano:** Conforto (Toyota Yaris Sedan) · **Perfil:** motorista_app · **App:** 99
- **Região:** Zona Sul · **Uso:** 748 km/mês · **Health score:** 46
- **Cliente desde:** 2026-06-08 · **Cancelou em:** 2026-06-17
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** “não rodei quase nada, não valeu a pena começar”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810001 · 2026-06-08 · whatsapp · Onboarding · CSAT 3/5

`09:21 UTC` **Cliente:** oi, assinei e paguei a primeira semana, e agora? quando pego o carro?
`09:34 UTC` **Driva:** Oi, Rafael! Boas-vindas 🎉 Falta só a vistoria pra liberar. Um consultor vai te chamar pra agendar.
`09:40 UTC` **Cliente:** beleza, fico no aguardo então

---

### Ticket #810002 · 2026-06-15 · whatsapp · Onboarding · CSAT 2/5

`20:04 UTC` **Cliente:** gente já faz 7 dias e ninguém agendou minha vistoria. cadê o carro?
`20:18 UTC` **Driva:** Rafael, sinto muito pela demora. Vou priorizar seu agendamento e te retorno hoje.
`20:29 UTC` **Cliente:** é a segunda vez que me falam isso. cada dia parado é dinheiro que não entra

---

### Ticket #810003 · 2026-06-17 · whatsapp · Cancelamento · CSAT 1/5

`10:19 UTC` **Cliente:** desisti. quero cancelar e pedir o estorno da semana que paguei sem nem ter recebido o carro
`10:21 UTC` **Driva:** Rafael, você tem razão e isso não deveria ter acontecido. Vou processar o estorno e registrar o cancelamento.
`10:26 UTC` **Cliente:** arrumei outra solução já, não dá pra esperar vocês
`10:30 UTC` **Driva:** Entendo. Registro algum motivo específico?
`10:45 UTC` **Cliente:** ah deixa quieto, não precisa marcar nada, só encerra

---
