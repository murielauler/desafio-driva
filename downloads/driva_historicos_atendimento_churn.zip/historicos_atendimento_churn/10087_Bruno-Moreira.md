# Histórico de atendimento — Cliente #10087 · Bruno Moreira

- **Plano:** Conforto (Toyota Yaris Sedan) · **Perfil:** motorista_app · **App:** Uber
- **Região:** ABC · **Uso:** 2353 km/mês · **Health score:** 38
- **Cliente desde** 2026-01-01 · **Cancelou em** 2026-06-30
- **Motivo registrado pela retenção:** problemas_manutencao
- **Comentário no cancelamento:** "fiquei 3 dias sem carro esperando conserto, não dá"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810046 · 2026-05-27 · whatsapp · Manutenção · CSAT 2/5

`15:31` **Cliente:** a luz da injeção acendeu e o carro tá falhando feio
`15:36` **Driva:** Bom dia, Bruno! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`15:56` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`16:03` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`16:17` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810047 · 2026-06-13 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`18:25` **Cliente:** o carro morreu aqui na Marginal Tietê, não liga de jeito nenhum. preciso de guincho AGORA
`18:36` **Driva:** Bruno, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`18:42` **Cliente:** quanto tempo demora?
`19:02` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`21:22` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`22:57` **Cliente:** 3h30 esperando. perdi a manhã inteira de trabalho. isso não dá
`23:03` **Driva:** Sinto muito de verdade pela demora, Bruno. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`23:08` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810048 · 2026-06-30 · whatsapp · Cancelamento · CSAT 1/5

`08:34` **Cliente:** oi, quero cancelar a assinatura
`08:41` **Driva:** Bruno, que pena ouvir isso. Posso entender o que motivou?
`08:55` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`08:57` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`09:11` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`09:30` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`09:49` **Cliente:** põe que foi a manutenção, sem dúvida

---
