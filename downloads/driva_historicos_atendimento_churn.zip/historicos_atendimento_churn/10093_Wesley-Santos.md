# Histórico de atendimento — Cliente #10093 · Wesley Santos

- **Plano:** Essencial (VW Gol) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Centro · **Uso:** 882 km/mês · **Health score:** 52
- **Cliente desde** 2025-04-06 · **Cancelou em** 2026-06-23
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** "só usava fim de semana, ficou caro"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810052 · 2026-03-06 · whatsapp · Planos · CSAT 3/5

`09:59` **Cliente:** boa tarde, eu uso o carro bem pouco, só pra ir e voltar do trabalho. tem um plano mais barato pra quem roda pouco?
`10:18` **Driva:** Boa tarde, Wesley! Hoje trabalhamos com os planos Essencial e Conforto, sem uma faixa de baixa quilometragem no momento.
`10:28` **Cliente:** poxa, pagar o mesmo que quem roda o dia todo não compensa pra mim
`10:31` **Driva:** Entendo seu ponto. Posso te mostrar se o Essencial reduz um pouco o custo?
`10:35` **Cliente:** é que mesmo o essencial tá caro pro tanto que eu ando

---

### Ticket #810053 · 2026-06-23 · whatsapp · Cancelamento · CSAT 2/5

`15:59` **Cliente:** vou cancelar, pro meu uso não vale a pena o valor semanal
`16:12` **Driva:** Wesley, respeito. Se em algum momento lançarmos um plano de baixa km, posso te avisar?
`16:31` **Cliente:** pode, mas por ora encerra aí
`16:38` **Driva:** Feito. Registro como qual motivo?
`16:53` **Cliente:** ah deixa quieto, não precisa marcar nada, só encerra

---
