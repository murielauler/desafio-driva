# Histórico de atendimento — Cliente #10093 · Wesley Santos

- **Plano:** Essencial (VW Gol) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Centro · **Uso:** 882 km/mês · **Health score:** 52
- **Cliente desde:** 2025-04-06 · **Cancelou em:** 2026-06-23
- **Motivo registrado pela retenção:** (em branco)
- **Comentário no cancelamento:** “só usava fim de semana, ficou caro”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810052 · 2025-06-28 · whatsapp · Planos · CSAT 3/5

`14:15 UTC` **Cliente:** boa tarde, eu uso o carro bem pouco, só pra ir e voltar do trabalho. tem um plano mais barato pra quem roda pouco?
`14:19 UTC` **Driva:** Boa tarde, Wesley! Hoje trabalhamos com os planos Essencial e Conforto, sem uma faixa de baixa quilometragem no momento.
`14:29 UTC` **Cliente:** poxa, pagar o mesmo que quem roda o dia todo não compensa pra mim
`14:44 UTC` **Driva:** Entendo seu ponto. Posso te mostrar se o Essencial reduz um pouco o custo?
`14:50 UTC` **Cliente:** é que mesmo o essencial tá caro pro tanto que eu ando

---

### Ticket #810053 · 2026-06-23 · whatsapp · Cancelamento · CSAT 2/5

`08:32 UTC` **Cliente:** vou cancelar, pro meu uso não vale a pena o valor semanal
`08:40 UTC` **Driva:** Wesley, respeito. Se em algum momento lançarmos um plano de baixa km, posso te avisar?
`08:53 UTC` **Cliente:** pode, mas por ora encerra aí
`09:13 UTC` **Driva:** Feito. Registro como qual motivo?
`09:31 UTC` **Cliente:** ah deixa quieto, não precisa marcar nada, só encerra

---
