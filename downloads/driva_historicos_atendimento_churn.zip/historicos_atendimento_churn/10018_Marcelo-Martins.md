# Histórico de atendimento — Cliente #10018 · Marcelo Martins

- **Plano:** Essencial (Chevrolet Onix) · **Perfil:** pessoal · **App:** Uso pessoal
- **Região:** Centro · **Uso:** 324 km/mês · **Health score:** 95
- **Cliente desde** 2025-07-22 · **Cancelou em** 2026-06-09
- **Motivo registrado pela retenção:** mudou_de_cidade
- **Comentário no cancelamento:** "achei uma opção melhor, valeu"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810015 · 2025-10-26 · whatsapp · Manutenção · CSAT 2/5

`07:25` **Cliente:** de novo problema no carro... tá difícil viu
`07:27` **Driva:** Marcelo, sinto muito. Vou abrir o chamado e resolver o quanto antes.
`07:40` **Cliente:** tô começando a achar que não vale a pena

---

### Ticket #810016 · 2026-06-09 · whatsapp · Cancelamento · CSAT 2/5

`19:55` **Cliente:** quero encerrar. achei uma opção melhor que me atende mais rápido
`20:11` **Driva:** Marcelo, poxa. Posso perguntar o que pesou na decisão?
`20:20` **Cliente:** sinceramente o atendimento e o carro reserva na hora, que aqui demora
`20:37` **Driva:** Justo. Que motivo você quer que eu registre no sistema?
`20:51` **Cliente:** marca que mudei de cidade

---
