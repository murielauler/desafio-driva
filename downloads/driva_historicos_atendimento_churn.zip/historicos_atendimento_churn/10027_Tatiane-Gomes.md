# Histórico de atendimento — Cliente #10027 · Tatiane Gomes

- **Plano:** Conforto (VW Virtus) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Norte · **Uso:** 2475 km/mês · **Health score:** 89
- **Cliente desde** 2026-04-01 · **Cancelou em** 2026-06-19
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** "consegui comprar meu próprio carro, valeu pela parceria"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810022 · 2026-05-03 · whatsapp · Dúvida app · CSAT 4/5

`18:48` **Cliente:** oi, tudo certo? só uma dúvida de como pausar a cobrança se eu viajar
`18:53` **Driva:** Oi, Tatiane! Consigo te explicar sim, é bem simples.
`18:59` **Cliente:** show, obrigado pelo atendimento sempre rápido

---

### Ticket #810023 · 2026-06-19 · whatsapp · Cancelamento · CSAT 5/5

`16:34` **Cliente:** oi! vim encerrar minha assinatura porque consegui comprar meu próprio carro 🙌
`16:38` **Driva:** Que notícia boa, Tatiane! Fico feliz pela conquista. Foi um prazer ter você com a gente.
`16:50` **Cliente:** vocês me ajudaram bastante nesse período, valeu de verdade
`16:59` **Driva:** Gratidão! A porta fica aberta se precisar voltar. 🧡

---
