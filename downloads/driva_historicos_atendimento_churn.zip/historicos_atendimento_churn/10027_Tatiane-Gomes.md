# Histórico de atendimento — Cliente #10027 · Tatiane Gomes

- **Plano:** Conforto (VW Virtus) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Norte · **Uso:** 2475 km/mês · **Health score:** 89
- **Cliente desde:** 2026-04-01 · **Cancelou em:** 2026-06-19
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** “consegui comprar meu próprio carro, valeu pela parceria”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810022 · 2026-04-15 · whatsapp · Dúvida app · CSAT 4/5

`08:53 UTC` **Cliente:** oi, tudo certo? só uma dúvida de como pausar a cobrança se eu viajar
`09:13 UTC` **Driva:** Oi, Tatiane! Consigo te explicar sim, é bem simples.
`09:21 UTC` **Cliente:** show, obrigado pelo atendimento sempre rápido

---

### Ticket #810023 · 2026-06-19 · whatsapp · Cancelamento · CSAT 5/5

`19:57 UTC` **Cliente:** oi! vim encerrar minha assinatura porque consegui comprar meu próprio carro 🙌
`20:17 UTC` **Driva:** Que notícia boa, Tatiane! Fico feliz pela conquista. Foi um prazer ter você com a gente.
`20:30 UTC` **Cliente:** vocês me ajudaram bastante nesse período, valeu de verdade
`20:36 UTC` **Driva:** Gratidão! A porta fica aberta se precisar voltar. 🧡

---
