# Histórico de atendimento — Cliente #10017 · Juliana Cardoso

- **Plano:** Conforto (Chevrolet Onix Plus) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Sul · **Uso:** 1724 km/mês · **Health score:** 42
- **Cliente desde** 2025-01-30 · **Cancelou em** 2026-06-11
- **Motivo registrado pela retenção:** problemas_manutencao
- **Comentário no cancelamento:** "carro vivia na oficina, perdi vários dias de corrida"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810012 · 2026-04-30 · whatsapp · Manutenção · CSAT 2/5

`12:41` **Cliente:** gente o carro não pega direito de manhã, já travou 2x essa semana
`12:54` **Driva:** Bom dia, Juliana! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`13:08` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`13:22` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`13:25` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810013 · 2026-05-24 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`12:53` **Cliente:** o carro morreu aqui na Rod. Anhanguera, não liga de jeito nenhum. preciso de guincho AGORA
`12:55` **Driva:** Juliana, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`13:01` **Cliente:** quanto tempo demora?
`13:17` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`15:37` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`17:12` **Cliente:** 3h30 esperando. perdi a manhã inteira de trabalho. isso não dá
`17:26` **Driva:** Sinto muito de verdade pela demora, Juliana. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`17:32` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810014 · 2026-06-11 · whatsapp · Cancelamento · CSAT 1/5

`17:31` **Cliente:** oi, quero cancelar a assinatura
`17:49` **Driva:** Juliana, que pena ouvir isso. Posso entender o que motivou?
`17:59` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`18:08` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`18:21` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`18:37` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`18:54` **Cliente:** marca problema de manutenção, foi isso mesmo

---
