# Histórico de atendimento — Cliente #10017 · Juliana Cardoso

- **Plano:** Conforto (Chevrolet Onix Plus) · **Perfil:** motorista_app · **App:** Uber
- **Região:** Zona Sul · **Uso:** 1724 km/mês · **Health score:** 42
- **Cliente desde:** 2025-01-30 · **Cancelou em:** 2026-06-11
- **Motivo registrado pela retenção:** problemas_manutencao
- **Comentário no cancelamento:** “carro vivia na oficina, perdi vários dias de corrida”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810012 · 2025-08-23 · whatsapp · Manutenção · CSAT 2/5

`09:34 UTC` **Cliente:** a luz da injeção acendeu e o carro tá falhando feio
`09:39 UTC` **Driva:** Bom dia, Juliana! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`09:57 UTC` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`10:07 UTC` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`10:16 UTC` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810013 · 2026-03-01 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`15:09 UTC` **Cliente:** o carro morreu aqui na 23 de Maio, não liga de jeito nenhum. preciso de guincho AGORA
`15:27 UTC` **Driva:** Juliana, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`15:33 UTC` **Cliente:** quanto tempo demora?
`15:48 UTC` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`18:08 UTC` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`19:43 UTC` **Cliente:** 3h30 esperando. perdi a tarde inteira de trabalho. isso não dá
`19:51 UTC` **Driva:** Sinto muito de verdade pela demora, Juliana. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`19:53 UTC` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810014 · 2026-06-11 · whatsapp · Cancelamento · CSAT 1/5

`07:40 UTC` **Cliente:** oi, quero cancelar a assinatura
`07:43 UTC` **Driva:** Juliana, que pena ouvir isso. Posso entender o que motivou?
`07:55 UTC` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`08:11 UTC` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`08:20 UTC` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`08:37 UTC` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`08:51 UTC` **Cliente:** põe que foi a manutenção, sem dúvida

---
