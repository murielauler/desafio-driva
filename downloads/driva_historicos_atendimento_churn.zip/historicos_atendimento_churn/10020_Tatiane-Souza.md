# Histórico de atendimento — Cliente #10020 · Tatiane Souza

- **Plano:** Essencial (Hyundai HB20) · **Perfil:** pessoal · **App:** Uso pessoal
- **Região:** Zona Sul · **Uso:** 193 km/mês · **Health score:** 68
- **Cliente desde** 2025-08-28 · **Cancelou em** 2026-06-28
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** "uso pouco, não compensa o valor semanal pra mim"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810017 · 2026-02-22 · whatsapp · Planos · CSAT 3/5

`14:45` **Cliente:** boa tarde, eu uso o carro bem pouco, só pra ir e voltar do trabalho. tem um plano mais barato pra quem roda pouco?
`14:50` **Driva:** Boa tarde, Tatiane! Hoje trabalhamos com os planos Essencial e Conforto, sem uma faixa de baixa quilometragem no momento.
`15:04` **Cliente:** poxa, pagar o mesmo que quem roda o dia todo não compensa pra mim
`15:15` **Driva:** Entendo seu ponto. Posso te mostrar se o Essencial reduz um pouco o custo?
`15:23` **Cliente:** é que mesmo o essencial tá caro pro tanto que eu ando

---

### Ticket #810018 · 2026-06-28 · whatsapp · Cancelamento · CSAT 2/5

`16:22` **Cliente:** vou cancelar, pro meu uso não vale a pena o valor semanal
`16:40` **Driva:** Tatiane, respeito. Se em algum momento lançarmos um plano de baixa km, posso te avisar?
`16:43` **Cliente:** pode, mas por ora encerra aí
`16:49` **Driva:** Feito. Registro como qual motivo?
`17:06` **Cliente:** pode botar que comprei um carro próprio, deixa quieto

---
