# Histórico de atendimento — Cliente #10020 · Tatiane Souza

- **Plano:** Essencial (Hyundai HB20) · **Perfil:** pessoal · **App:** Uso pessoal
- **Região:** Zona Sul · **Uso:** 193 km/mês · **Health score:** 68
- **Cliente desde:** 2025-08-28 · **Cancelou em:** 2026-06-28
- **Motivo registrado pela retenção:** comprou_carro_proprio
- **Comentário no cancelamento:** “uso pouco, não compensa o valor semanal pra mim”

> ⚠️ O motivo registrado é pouco confiável. Compare-o com as conversas abaixo para identificar o que realmente aconteceu.
> Os horários estão em UTC, exatamente como no export JSON.

---

### Ticket #810017 · 2025-11-22 · whatsapp · Planos · CSAT 3/5

`14:51 UTC` **Cliente:** boa tarde, eu uso o carro bem pouco, só pra ir e voltar do trabalho. tem um plano mais barato pra quem roda pouco?
`15:08 UTC` **Driva:** Boa tarde, Tatiane! Hoje trabalhamos com os planos Essencial e Conforto, sem uma faixa de baixa quilometragem no momento.
`15:27 UTC` **Cliente:** poxa, pagar o mesmo que quem roda o dia todo não compensa pra mim
`15:36 UTC` **Driva:** Entendo seu ponto. Posso te mostrar se o Essencial reduz um pouco o custo?
`15:45 UTC` **Cliente:** é que mesmo o essencial tá caro pro tanto que eu ando

---

### Ticket #810018 · 2026-06-28 · whatsapp · Cancelamento · CSAT 2/5

`10:08 UTC` **Cliente:** vou cancelar, pro meu uso não vale a pena o valor semanal
`10:13 UTC` **Driva:** Tatiane, respeito. Se em algum momento lançarmos um plano de baixa km, posso te avisar?
`10:28 UTC` **Cliente:** pode, mas por ora encerra aí
`10:30 UTC` **Driva:** Feito. Registro como qual motivo?
`10:37 UTC` **Cliente:** pode botar que comprei um carro próprio, deixa quieto

---
