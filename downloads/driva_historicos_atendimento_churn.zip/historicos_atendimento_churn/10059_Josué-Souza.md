# Histórico de atendimento — Cliente #10059 · Josué Souza

- **Plano:** Essencial (Chevrolet Onix) · **Perfil:** motorista_app · **App:** Ambos
- **Região:** Zona Norte · **Uso:** 1674 km/mês · **Health score:** 66
- **Cliente desde** 2025-01-23 · **Cancelou em** 2026-06-06
- **Motivo registrado pela retenção:** achei_caro
- **Comentário no cancelamento:** "carro vivia na oficina, perdi vários dias de corrida"

> ⚠️ O *motivo registrado* é o campo operacional (pouco confiável). Leia as conversas abaixo para entender o que **realmente** aconteceu.

---

### Ticket #810035 · 2026-03-16 · whatsapp · Manutenção · CSAT 2/5

`09:55` **Cliente:** a luz da injeção acendeu e o carro tá falhando feio
`10:14` **Driva:** Bom dia, Josué! Poxa, sinto muito por isso. Já abri um chamado e vou agendar a oficina mais perto de você. Consegue levar amanhã cedo?
`10:28` **Cliente:** amanhã?? mano eu rodo de manhã, é quando mais faço corrida. não tem hoje não?
`10:40` **Driva:** Entendo total, carro parado é renda parada. Vou tentar encaixar hoje à tarde e te confirmo já já.
`10:55` **Cliente:** por favor não me deixa na mão que eu dependo disso

---

### Ticket #810036 · 2026-05-17 · whatsapp · Guincho · CSAT 1/5 · 🚨 guincho acionado

`13:20` **Cliente:** o carro morreu aqui na Av. Sapopemba, não liga de jeito nenhum. preciso de guincho AGORA
`13:34` **Driva:** Josué, já estou acionando o guincho pra sua localização. Fica em segurança, por favor.
`13:40` **Cliente:** quanto tempo demora?
`13:44` **Driva:** A previsão inicial é de até 2h, mas vou monitorar de perto.
`16:04` **Cliente:** cara já faz mais de 2h e nada... tô parado no sol até agora
`17:39` **Cliente:** 3h30 esperando. perdi a manhã inteira de trabalho. isso não dá
`17:57` **Driva:** Sinto muito de verdade pela demora, Josué. O guincho chega em ~30 min. Vou lançar um crédito pelo transtorno.
`18:08` **Cliente:** crédito não paga as corridas que eu perdi hoje

---

### Ticket #810037 · 2026-06-06 · whatsapp · Cancelamento · CSAT 1/5

`19:11` **Cliente:** oi, quero cancelar a assinatura
`19:30` **Driva:** Josué, que pena ouvir isso. Posso entender o que motivou?
`19:44` **Cliente:** 3 semanas seguidas com o carro na oficina ou esperando guincho. não consigo trabalhar assim, tô no prejuízo todo dia
`19:49` **Driva:** Você tem toda razão e a gente falhou no que mais importa: te manter rodando. Posso te oferecer troca imediata de carro + uma semana de cortesia. Topa tentar mais uma vez?
`19:55` **Cliente:** não dá mais não, já perdi a confiança. pode encerrar
`20:07` **Driva:** Respeito sua decisão. Vou registrar o cancelamento. Que motivo você quer que eu marque?
`20:27` **Cliente:** marca que ficou caro pra mim, é isso

---
